<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class IPWhiteList extends Model
{
    use HasFactory;

    protected $table = 'ip_white_lists';

    protected $fillable = [
        'whitelist_ip',
    ];
}
