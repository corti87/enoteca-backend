<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Http\Requests\User\ShowRequest;
use App\Http\Requests\User\IsAdminRequest;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\User;

class ShowController extends Controller
{
    public function showInfo(ShowRequest $request)
    {
        return response()->json([
            'user' => Auth::user()
            // KEY 'user' => Value Auth::user()
            //키 'user' Auth::user()(로그인한유저:request
        ]);
    }

    public function showAllInfo(IsAdminRequest $request)
    {

        return response()->json([

            'users' => User::all()
        ]);
        // return response()->json([
        //     'users' => Auth::user()->admin-> DB::select('select * from users')
        // ]);
    }
}
